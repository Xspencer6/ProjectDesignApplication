# Ceramic Tile Surface Defects > LATEST VERSION - NORMAL TILES
https://universe.roboflow.com/spencerworkspace/ceramic-tile-surface-defects

Provided by a Roboflow user
License: CC BY 4.0

